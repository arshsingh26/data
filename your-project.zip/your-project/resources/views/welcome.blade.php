
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">


        <title>ATGController</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                margin: auto;
                text-align: center;
                width: 360px;
                height: 230px;
                border: 3px solid black;
                padding: 60px;
            }

            .title {
                font-size: 54px;
            }

            .m-b-md {
                margin-bottom: 0px;
                text-align: center;
            }	

            .form1 {
                margin: 0px auto;
                padding: 30px 20px;
                width: 300px;
                font-size: 20px;
            }
        </style>

    </head>
    <body>

            <div class="content">
                <div class="title m-b-md">
                    Enter Details
                </div>

                <div class="form1">
                <form  action="create" method="post">
                    @csrf
    			<table id="form">
        		<tr>
        		<th id="lebel1" style="color:black;">Name: </th>
        		<th id="lebel1"><input type="text" name="name" placeholder="Enter Name" required></th>
                </tr>
                <tr>
                <th id="lebel1" style="color: black;">Email ID: </th>
                <th id="lebel1"><input type="email" name="email" placeholder="Email ID" data-validation="email" required></th>
        		</tr>
                <tr>
                <tr>
                <th id="lebel1" style="color: black;">Pin Code: </th>
                <th id="lebel1"><input type="pin" name="pin" placeholder="Pin code" maxlength="6" required>
                </th>
                </tr>
                <tr>
                <th></th>
                <th><br>
                    <button type="submit" name="submit" style="padding:10px 20px;color:white;background-color:#1a75ff;cursor:pointer;">Submit</button><br>
                </th>
                </tr>
            </tr>
        </table>
    </form>
    <br>

            </div>
            </div>
            <div class="row">
            <div class="col-md-12">
        <br>
       
    </body>
</html>
