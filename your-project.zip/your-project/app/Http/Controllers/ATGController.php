<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Data;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Database\QueryException;
class ATGController extends Controller {
public function insertform()
{	

	return view('welcome');
}



public function insert(Request $request){
$name = $request->input('name');
$email = $request->input('email');
$pin = $request->input('pin');
$data=array('name'=>$name,'email'=>$email,'pin'=>$pin);
try {
	DB::table('data')->insert($data);
	echo "Record inserted successfully.<br/>";
	echo '<a href = "/insert">Click Here</a> to go back.';
      }catch (QueryException $e) {
            $errorCode = $e->errorInfo[1];          
            if($errorCode == 1062){
                echo "E-Mail Already exist.<br><br>";
                echo '<a href = "/insert">Click Here</a> to go back.';
            }
        }
    }
}

